import { AuthAction } from '../actions'; // TODO: should make typescript read this from tsconfig.

export class AuthState {
  token: string;
  username: string;
}
export const AUTH_SET_TOKEN = 'AUTH_SET_TOKEN';
export type AUTH_SET_TOKEN = typeof AUTH_SET_TOKEN;
export default (
  state: AuthState = { token: '', username: '' },
  action: AuthAction
): AuthState => {
  switch (action.type) {
    case AUTH_SET_TOKEN:
      return {
        ...state,
        token: action.payload.token,
        username: action.payload.username || '',
      };
    default:
      return state;
  }
};
