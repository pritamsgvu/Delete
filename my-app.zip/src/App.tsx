import * as React from 'react';
import * as actions from './actions';

// import { StoreState } from '../../types/index';
import './App.css';

const logo = require('./logo.svg');

// TODO: use selectors.
export const mapStateToProps = (state: any) => ({
  token: state.auth.token,
  username: state.auth.username,
});

export const mapDispatchToProps = {
  submitLoginForm: actions.submitLoginForm,
};

export interface Props {
  token: string;
  username: string;
  submitLoginForm: (
    username: string,
    password: string,
    rememberMe: boolean
  ) => void;
}

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.tsx</code> and save to reload.
        </p>
      </div>
    );
  }
}

export default App;
