export const AUTH_IS_LOGGED_IN = 'AUTH_IS_LOGGED_IN';
export type AUTH_IS_LOGGED_IN = typeof AUTH_IS_LOGGED_IN;

export const AUTH_SET_TOKEN = 'AUTH_SET_TOKEN';
export type AUTH_SET_TOKEN = typeof AUTH_SET_TOKEN;

export const AUTH_SUBMIT_LOGIN_FORM = 'AUTH_SUBMIT_LOGIN_FORM';
export type AUTH_SUBMIT_LOGIN_FORM = typeof AUTH_SUBMIT_LOGIN_FORM;

// Auth actions

export interface IsLoggedIn {
    type: AUTH_IS_LOGGED_IN;
}

export interface SetToken {
    type: AUTH_SET_TOKEN;
    payload: {
        token: string;
        username?: string;
    };
}

export interface SubmitLoginForm {
    type: AUTH_SUBMIT_LOGIN_FORM;
    payload: {
        username: string;
        password: string;
        rememberMe: boolean;
    };
}

export const setToken = (token: string, username = ''): SetToken => ({
    type: AUTH_SET_TOKEN,
    payload: {
        token,
        username,
    },
});

export const submitLoginForm = (
    username: string,
    password: string,
    rememberMe: boolean
): SubmitLoginForm => ({
    type: AUTH_SUBMIT_LOGIN_FORM,
    payload: {
        username,
        password,
        rememberMe,
    },
});

export type AuthAction = IsLoggedIn | SetToken | SubmitLoginForm;