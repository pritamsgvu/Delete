// declare var toastr: any;
import { delay } from 'redux-saga';
import { call } from 'redux-saga/effects';
import { SubmitLoginForm } from '../actions';
/**
 * TODO: refactor this mess.
 */
export function* handleSubmitLoginForm(action: SubmitLoginForm) {
    // For debounce.
    yield call(delay, 500);
    // const { username, password } = action.payload;
    try {
        const response = yield call(fetch, `user/register`, {
            method: 'POST',
            body: JSON.stringify({
                username: 'pritam',
            }),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        const json = yield call([response, 'json']);
        // console.log('jsonjsonjson', json);

        if (!json.access_token) {
            throw Error();
        }
        // TODO: handle error.
        // yield call([localStorage, 'setItem'], 'token', json.access_token);
        // if (rememberMe) {
        //     yield call([localStorage, 'setItem'], 'username', username);
        // } else {
        //     yield call([localStorage, 'removeItem'], 'username');
        // }
    } catch (e) {
        alert('erroor');
        // yield call(
        //     [toastr, 'error'],
        //     `<p>The credentials that you've entered is incorrect.</p>` +
        //     'Login Failed'
        // );

        // TODO: handle errors.
    }
}